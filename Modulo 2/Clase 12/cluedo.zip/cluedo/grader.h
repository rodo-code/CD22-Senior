int Theory(int M, int L, int W);
