#include "grader.h"
#include "memory.h"

void play() {
   int i;
   char a, b;
   for (i=0; i<10; ++i) {
      a = faceup(42);
      b = faceup(47);
   }
}
