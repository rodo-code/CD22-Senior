char faceup(int C);
